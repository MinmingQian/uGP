g++ -std=c++11 main.cpp nk-cpp/NK.cpp nk-cpp/Random.cpp -o nk-landscapes

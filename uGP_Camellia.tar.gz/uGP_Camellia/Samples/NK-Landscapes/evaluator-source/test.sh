./nk-landscapes --n 4 --k 2 --a 2 --input individual.txt --output fitness.output --randomSeed 1234
./nk-landscapes --n 4 --k 2 --a 2 --reverse --input individual.txt --output fitness.reverse --randomSeed 1234

#!/bin/bash

rm -f core
rm -f fitness.out
rm -f i*.s
rm -f *.log
rm -f main.o
rm -f statistics.*
rm -f status.xml
rm -f tprog
rm -f individualsToEvaluate.txt
rm -f BEST_*.s

g++ evaluator.cpp -std=c++11 -lm -o evaluator

#!/bin/bash

rm -f core
rm -f fitness.out
rm -f *.log
rm -f individual_*.in
rm -f statistics.csv
rm -f statistics_*.csv
rm -f status.xml
rm -f BEST_*.input
rm -f evaluator
rm -f ugp3.pid

echo "Compiling evaluator..."
g++ evaluator.cpp -o evaluator
echo "Starting ugp3..."
ugp3

#ifndef HEADER_BANANA
#define HEADER_BANANA

double banana(double x1, double x2);

#endif

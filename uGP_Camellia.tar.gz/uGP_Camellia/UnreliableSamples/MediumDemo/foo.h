extern int foo(int a);
extern int foo2(int a, int b);

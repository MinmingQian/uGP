#!/bin/bash

rm Evaluator
#g++ path.cpp -Wall -o myeval
echo "compiling..."


# -g x debug
g++  -Wall evaluator.cpp -o Evaluator


